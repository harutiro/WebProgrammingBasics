const name = '';

if(name){
    console.log('名前が存在します');
}else{
    console.log('名前がありません');
}