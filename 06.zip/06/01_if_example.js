const price = 3000;

if(price >= 5000){
    console.log('送料無料');
}else{
    console.log('送料800円');
}